

import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class CarRentalTester {

    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        //make the object of CarRental
        CarRental rental; // rental is a reference variables. double(type-CarRental) var(variable name-rental);
        rental = new CarRental("Halil","SUV",3);

        // double var
        System.out.println("Enter cost per day of SUV");
        double cost = Scan.nextDouble(); 
        System.out.println(rental.displayRentalQuote(cost));
    }
    
}
