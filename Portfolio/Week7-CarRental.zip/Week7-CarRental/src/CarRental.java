/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class CarRental {

    private String customerName; //null
    private int numOfDays; //0
    private String typeOfCar; //null
    private final double TAX = 0.08;

    public CarRental(String name, String type, int days){
        customerName = name;
        typeOfCar = type;
        numOfDays = days;
    }

    public double makeBill(double costPerDay){
        double bill = costPerDay * numOfDays;
        bill = bill + (bill * TAX);
        return bill;
    }
    
    /*public void displayRentalQuote(double costPerDay){
        System.out.println("Customer Name: " + customerName);
        System.out.println("Number of days: " + typeOfCar + " is rented for " + numOfDays);
        System.out.println("Total bill: " + String.format("%.2f", makeBill(costPerDay)));
    }
    */
    public String displayRentalQuote(double costPerDay){
        String myOutput = "";
        myOutput += ("Customer Name: " + customerName);
        myOutput += ("\nNumber of days: " + typeOfCar + " is rented for " + numOfDays);
        myOutput += ("\nTotal bill: " + String.format("%.2f", makeBill(costPerDay)));
        return myOutput;
    }
    
}
