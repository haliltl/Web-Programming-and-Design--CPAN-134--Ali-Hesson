
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class Lab6ComplexNumberIfStatementsTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lab6ComplexNumberIfStatements comNum = new Lab6ComplexNumberIfStatements();
        Scanner keyboard = new Scanner(System.in);
        comNum.inputComplexNumber(keyboard);
        System.out.println("Your complex number is: " + comNum.printComplexNumber());
        System.out.println("Please enter a number to multiply your complex number by");
        int multiplier = keyboard.nextInt();
        comNum.multiply(multiplier);
        System.out.println("The multiplied complex number is: " + comNum.printComplexNumber());
        
    }
}