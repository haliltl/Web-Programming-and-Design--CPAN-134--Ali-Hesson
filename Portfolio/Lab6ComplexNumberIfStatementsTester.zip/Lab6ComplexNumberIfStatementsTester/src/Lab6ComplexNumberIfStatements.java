
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class Lab6ComplexNumberIfStatements {
    private double realPart;
    private double imagPart;
    
    public Lab6ComplexNumberIfStatements(){
        realPart = 0;
        imagPart = 0;
    }
    
    public void inputComplexNumber(Scanner scan){
        double adjustment = 0;
        System.out.println("Please enter a real number followed by an imaginary number");
        realPart = scan.nextDouble();
        imagPart = scan.nextDouble();
        
    }
    
    public void multiply(int multiplier){
        realPart *= multiplier;
        imagPart *= multiplier;
    }
    
    public String printComplexNumber(){
        String adjustment = "";
        if(realPart == 0)
        {
            adjustment += imagPart;
            adjustment += "i";
        }
        else if(imagPart == 0)
            adjustment += realPart;
        else if(imagPart <= 0)
            adjustment += realPart + " + " + "(" + imagPart + ")" + "i";
        else{
            adjustment += realPart + " + " + imagPart + "i";
        }
        return adjustment;    
    }
          
 }
                
